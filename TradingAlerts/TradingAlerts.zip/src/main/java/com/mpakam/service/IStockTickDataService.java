package com.mpakam.service;

public interface IStockTickDataService {

	public void saveCurrentPriceForAllMonitoredStocks();
	
}
